#!/bin/bash

# install required packages
apk add --no-cache py3-opencv bash
